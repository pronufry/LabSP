#!/bin/bash
x="68"
napis="tresc napisu"
echo "$x "
echo "$napis"
