#!/bin/bash
x="12345"
y="98765"
z="$[x+y]"

echo "$z"
