#!/bin/bash
x="Kacper Gasiewicz"
echo "nazywam sie $x"

