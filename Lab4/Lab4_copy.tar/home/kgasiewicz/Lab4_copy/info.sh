#!/bin/bash
echo "`whoami` $SHELL $OSTYPE `date` $HOME" > dane.dat



