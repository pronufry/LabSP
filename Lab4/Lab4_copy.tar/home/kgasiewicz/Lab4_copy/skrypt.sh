#!/bin/bash
#Tu jest komentarz.
echo "$1 $2 $3"
