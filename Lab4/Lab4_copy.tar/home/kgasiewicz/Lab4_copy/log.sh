#!/bin/bash
echo "`w`"



